export const colors = {}
